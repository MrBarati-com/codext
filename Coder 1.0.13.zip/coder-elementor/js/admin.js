/**
 * Coder for Elementor
 * Fully customizable Elementor add-on for syntax highlighting in over 200 languages.
 * Exclusively on https://1.envato.market/coder-elementor
 *
 * @encoding        UTF-8
 * @version         1.0.13
 * @copyright       (C) 2018 - 2021 Merkulove ( https://merkulov.design/ ). All rights reserved.
 * @license         Envato License https://1.envato.market/KYbje
 * @contributors    Nemirovskiy Vitaliy (nemirovskiyvitaliy@gmail.com), Dmitry Merkulov (dmitry@merkulov.design)
 * @support         help@merkulov.design
 **/
