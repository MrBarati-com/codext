<?php /** @noinspection PhpUndefinedClassInspection */
/**
 * Coder for Elementor
 * Fully customizable Elementor add-on for syntax highlighting in over 200 languages.
 * Exclusively on https://1.envato.market/coder-elementor
 *
 * @encoding        UTF-8
 * @version         1.0.13
 * @copyright       (C) 2018 - 2021 Merkulove ( https://merkulov.design/ ). All rights reserved.
 * @license         Envato License https://1.envato.market/KYbje
 * @contributors    Nemirovskiy Vitaliy (nemirovskiyvitaliy@gmail.com), Dmitry Merkulov (dmitry@merkulov.design)
 * @support         help@merkulov.design
 **/

namespace Merkulove\CoderElementor;

/** Exit if accessed directly. */
if ( ! defined( 'ABSPATH' ) ) {
    header( 'Status: 403 Forbidden' );
    header( 'HTTP/1.1 403 Forbidden' );
    exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Exception;
use Elementor\Plugin;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Merkulove\CoderElementor\Unity\Plugin as UnityPlugin;
use Merkulove\CoderElementor\Unity\ElementorControls;

/** @noinspection PhpUnused */
/**
 * Coder - Custom Elementor Widget.
 **/
class coder_elementor extends Widget_Base {

    /**
     * Use this to sort widgets.
     * A smaller value means earlier initialization of the widget.
     * Can take negative values.
     * Default widgets and widgets from 3rd party developers have 0 $mdp_order
     **/
    public $mdp_order = 1;

    /**
     * Widget Styles.
     *
     * @string version
     * @since 1.0.0
     **/
    public $styles = [];

    /**
     * Widget Scripts.
     *
     * @string version
     * @since 1.0.0
     **/
    public $scripts = [];

    /**
     * Widget base constructor.
     *
     * Initializing the widget base class.
     *
     * @since 1.0.0
     * @access public
     *
     * @throws Exception If arguments are missing when initializing a full widget instance.
     *
     * @param array      $data Widget data. Default is an empty array.
     * @param array|null $args Optional. Widget default arguments. Default is null.
     **/
    public function __construct( $data = [], $args = null ) {

        parent::__construct( $data, $args );

        /** CSS Styles. */
        wp_register_style( 'mdp-coder-elementor-widget', UnityPlugin::get_url() . 'css/coder' . UnityPlugin::get_suffix() . '.css', [], UnityPlugin::get_version() );

        /** JavaScript. */
        wp_enqueue_script( 'jquery' );
        wp_register_script( 'mdp-prism-js', UnityPlugin::get_url() . 'js/prism' . UnityPlugin::get_suffix() . '.js', ['jquery'], UnityPlugin::get_version(), true );

        /** PrismJS Plugins. */

        /** Line Numbers. */
        wp_register_style( 'mdp-prism-line-numbers', UnityPlugin::get_url() . 'css/prism/prism-line-numbers' . UnityPlugin::get_suffix() . '.css', [], UnityPlugin::get_version() );
        wp_register_script( 'mdp-prism-line-numbers-js', UnityPlugin::get_url() . 'js/prism/plugins/line-numbers/prism-line-numbers' . UnityPlugin::get_suffix() . '.js', ['mdp-prism-js'], UnityPlugin::get_version(), true );

        /** Line Highlight. */
        wp_register_style( 'mdp-prism-line-highlight', UnityPlugin::get_url() . 'css/prism/prism-line-highlight' . UnityPlugin::get_suffix() . '.css', [], UnityPlugin::get_version() );
        wp_register_script( 'mdp-prism-line-highlight-js', UnityPlugin::get_url() . 'js/prism/plugins/line-highlight/prism-line-highlight' . UnityPlugin::get_suffix() . '.js', ['mdp-prism-js'], UnityPlugin::get_version(), true );

        /** Show Invisibles. */
        wp_register_style( 'mdp-prism-show-invisibles', UnityPlugin::get_url() . 'css/prism/prism-show-invisibles' . UnityPlugin::get_suffix() . '.css', [], UnityPlugin::get_version() );
        wp_register_script( 'mdp-prism-show-invisibles-js', UnityPlugin::get_url() . 'js/prism/plugins/show-invisibles/prism-show-invisibles' . UnityPlugin::get_suffix() . '.js', ['mdp-prism-js'], UnityPlugin::get_version(), true );

        /** Autolinker. */
        wp_register_style( 'mdp-prism-autolinker', UnityPlugin::get_url() . 'css/prism/prism-autolinker' . UnityPlugin::get_suffix() . '.css', [], UnityPlugin::get_version() );
        wp_register_script( 'mdp-prism-autolinker-js', UnityPlugin::get_url() . 'js/prism/plugins/autolinker/prism-autolinker' . UnityPlugin::get_suffix() . '.js', ['mdp-prism-js'], UnityPlugin::get_version(), true );

        /** Show Language. */
        wp_register_script( 'mdp-prism-show-language-js', UnityPlugin::get_url() . 'js/prism/plugins/show-language/prism-show-language' . UnityPlugin::get_suffix() . '.js', ['mdp-prism-js'], UnityPlugin::get_version(), true );

        /** Inline color. */
        wp_register_style( 'mdp-prism-inline-color', UnityPlugin::get_url() . 'css/prism/prism-inline-color' . UnityPlugin::get_suffix() . '.css', [], UnityPlugin::get_version() );
        wp_register_script( 'mdp-prism-css-js', UnityPlugin::get_url() . 'js/prism/components/prism-css' . UnityPlugin::get_suffix() . '.js', ['mdp-prism-js'], UnityPlugin::get_version(), true );
        wp_register_script( 'mdp-prism-css-extras-js', UnityPlugin::get_url() . 'js/prism/components/prism-css-extras' . UnityPlugin::get_suffix() . '.js', ['mdp-prism-js', 'mdp-prism-css-js'], UnityPlugin::get_version(), true );
        wp_register_script( 'mdp-prism-inline-color-js', UnityPlugin::get_url() . 'js/prism/plugins/inline-color/prism-inline-color' . UnityPlugin::get_suffix() . '.js', ['mdp-prism-js'], UnityPlugin::get_version(), true );

        /** Previewers. */
        wp_register_style( 'mdp-prism-previewers', UnityPlugin::get_url() . 'css/prism/prism-previewers' . UnityPlugin::get_suffix() . '.css', [], UnityPlugin::get_version() );
        wp_register_script( 'mdp-prism-previewers-js', UnityPlugin::get_url() . 'js/prism/plugins/previewers/prism-previewers' . UnityPlugin::get_suffix() . '.js', ['mdp-prism-js'], UnityPlugin::get_version(), true );

        /** WebPlatform Docs. */
        wp_register_style( 'mdp-prism-wpd', UnityPlugin::get_url() . 'css/prism/prism-wpd' . UnityPlugin::get_suffix() . '.css', [], UnityPlugin::get_version() );
        wp_register_script( 'mdp-prism-wpd-js', UnityPlugin::get_url() . 'js/prism/plugins/wpd/prism-wpd' . UnityPlugin::get_suffix() . '.js', ['mdp-prism-js'], UnityPlugin::get_version(), true );

        /** Command Line. */
        wp_register_style( 'mdp-prism-command-line', UnityPlugin::get_url() . 'css/prism/prism-command-line' . UnityPlugin::get_suffix() . '.css', [], UnityPlugin::get_version() );
        wp_register_script( 'mdp-prism-command-line-js', UnityPlugin::get_url() . 'js/prism/plugins/command-line/prism-command-line' . UnityPlugin::get_suffix() . '.js', ['mdp-prism-js'], UnityPlugin::get_version(), true );

        /** Treeview. */
        wp_register_style( 'mdp-prism-treeview', UnityPlugin::get_url() . 'css/prism/prism-treeview' . UnityPlugin::get_suffix() . '.css', [], UnityPlugin::get_version() );
        wp_register_script( 'mdp-prism-treeview-js', UnityPlugin::get_url() . 'js/prism/plugins/treeview/prism-treeview' . UnityPlugin::get_suffix() . '.js', ['mdp-prism-js'], UnityPlugin::get_version(), true );

        /** Copy to Clipboard Button. */
        wp_register_script( 'mdp-prism-copy-to-clipboard-js', UnityPlugin::get_url() . 'js/prism/plugins/copy-to-clipboard/prism-copy-to-clipboard' . UnityPlugin::get_suffix() . '.js', ['mdp-prism-js'], UnityPlugin::get_version(), true );

        /** Download Button. */
        wp_register_script( 'mdp-prism-download-button-js', UnityPlugin::get_url() . 'js/prism/plugins/download-button/prism-download-button' . UnityPlugin::get_suffix() . '.js', ['mdp-prism-js'], UnityPlugin::get_version(), true );

        /** Match braces. */
        wp_register_style( 'mdp-prism-match-braces', UnityPlugin::get_url() . 'css/prism/prism-match-braces' . UnityPlugin::get_suffix() . '.css', [], UnityPlugin::get_version() );
        wp_register_script( 'mdp-prism-match-braces-js', UnityPlugin::get_url() . 'js/prism/plugins/match-braces/prism-match-braces' . UnityPlugin::get_suffix() . '.js', ['mdp-prism-js'], UnityPlugin::get_version(), true );

        /** Diff Highlight. */
        wp_register_style( 'mdp-prism-diff-highlight', UnityPlugin::get_url() . 'css/prism/prism-diff-highlight' . UnityPlugin::get_suffix() . '.css', [], UnityPlugin::get_version() );
        wp_register_script( 'mdp-prism-diff-js', UnityPlugin::get_url() . 'js/prism/components/prism-diff' . UnityPlugin::get_suffix() . '.js', ['mdp-prism-js'], UnityPlugin::get_version(), true );
        wp_register_script( 'mdp-prism-diff-highlight-js', UnityPlugin::get_url() . 'js/prism/plugins/diff-highlight/prism-diff-highlight' . UnityPlugin::get_suffix() . '.js', ['mdp-prism-js', 'mdp-prism-diff-js'], UnityPlugin::get_version(), true );

        /** Add additional attribute in Script Tag for prism-js. */
        add_filter( 'script_loader_tag', [$this, 'add_manual_to_script'], 10, 3 );

    }

    /**
     * Add additional attribute in Script Tag for prism-js.
     *
     * @param $tag
     * @param $handle
     * @param $source
     *
     * @since 1.0.0
     * @return string
     **/
    public function add_manual_to_script( $tag, $handle, $source ) {

        if ( 'mdp-prism-js' === $handle ) {

            $tag = '<script>window.Prism = window.Prism || {}; window.Prism.manual = true;</script><script data-cfasync="false" type="text/javascript" src="' . $source . '" data-manual=""></script>';

        }

        return $tag;

    }

    /**
     * Return a widget name.
     *
     * @return string
     * @since 1.0.0
     **/
    public function get_name() {

        return 'mdp-coder-elementor';

    }

    /**
     * Return the widget title that will be displayed as the widget label.
     *
     * @return string
     * @since 1.0.0
     **/
    public function get_title() {

        return esc_html__( 'Coder', 'coder-elementor' );

    }

    /**
     * Set the widget icon.
     *
     * @return string
     * @since 1.0.0
     */
    public function get_icon() {

        return 'mdp-coder-elementor-widget-icon';

    }

    /**
     * Set the category of the widget.
     *
     * @since 1.0.0
     *
     * @return array with category names
     **/
    public function get_categories() {

        return ['general'];

    }

    /**
     * Get widget keywords. Retrieve the list of keywords the widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget keywords.
     **/
    public function get_keywords() {

        return ['Merkulove', 'Coder', 'Highlight', 'Source Code', 'Syntax Highlighter', 'html', 'php', 'css'];

    }

    /**
     * Get script dependencies.
     *
     * Retrieve the list of script dependencies the element requires.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Element scripts dependencies.
     **/
    public function get_script_depends() {

        /**
         * Editor Mode.
         * In the edit mode, get_script_depends() does not have access to get_settings()
         * or get_settings_for_display() functions.
         * So, the solution would be, enqueue all the scripts for edit and preview mode,
         * whereas use conditional enqueue for the frontend.
         **/
        if (
            Plugin::$instance->editor->is_edit_mode() ||
            Plugin::$instance->preview->is_preview_mode()
        ) {
            return [
                'mdp-prism-js',
                'mdp-prism-line-numbers-js',
                'mdp-prism-line-highlight-js',
                'mdp-prism-show-invisibles-js',
                'mdp-prism-autolinker-js',
                'mdp-prism-show-language-js',
                'mdp-prism-css-js',
                'mdp-prism-css-extras-js',
                'mdp-prism-inline-color-js',
                'mdp-prism-previewers-js',
                'mdp-prism-wpd-js',
                'mdp-prism-command-line-js',
                'mdp-prism-treeview-js',
                'mdp-prism-copy-to-clipboard-js',
                'mdp-prism-download-button-js',
                'mdp-prism-match-braces-js',
                'mdp-prism-diff-js',
                'mdp-prism-diff-highlight-js',
            ];
        }

        /** Get Widget Settings. */
        $settings = $this->get_settings_for_display();

        /** Core Widget Styles and Scripts. */
        $this->scripts[] = 'mdp-prism-js';

        /** Line Numbers @see https://prismjs.com/plugins/line-numbers/ */
        if ( 'yes' === $settings['line_numbers'] ) {
            $this->scripts[] = 'mdp-prism-line-numbers-js';
        }

        /** Line Highlight @see https://prismjs.com/plugins/line-highlight/ */
        if ( 'yes' === $settings['line_highlight'] ) {
            $this->scripts[] = 'mdp-prism-line-highlight-js';
        }

        /** Show Invisibles @see https://prismjs.com/plugins/show-invisibles/ */
        if ( 'yes' === $settings['show_invisibles'] ) {
            $this->scripts[] = 'mdp-prism-show-invisibles-js';
        }

        /** Autolinker @see https://prismjs.com/plugins/autolinker/ */
        if ( 'yes' === $settings['autolinker'] ) {
            $this->scripts[] = 'mdp-prism-autolinker-js';
        }

        /** Show Language @see https://prismjs.com/plugins/show-language/ */
        if ( 'yes' === $settings['show_language'] ) {
            $this->scripts[] = 'mdp-prism-show-language-js';
        }

        /** Inline color @see https://prismjs.com/plugins/inline-color/ */
        if ( 'yes' === $settings['inline_color'] ) {
            $this->scripts[] = 'mdp-prism-css-js';
            $this->scripts[] = 'mdp-prism-css-extras-js';
            $this->scripts[] = 'mdp-prism-inline-color-js';
        }

        /** Previewers @see https://prismjs.com/plugins/previewers/ */
        if ( 'yes' === $settings['previewers'] ) {
            $this->scripts[] = 'mdp-prism-css-js';
            $this->scripts[] = 'mdp-prism-css-extras-js';
            $this->scripts[] = 'mdp-prism-previewers-js';
        }

        /** WebPlatform Docs @see https://prismjs.com/plugins/wpd/ */
        if ( 'yes' === $settings['webplatform_docs'] ) {
            $this->scripts[] = 'mdp-prism-wpd-js';
        }

        /** Command Line @see https://prismjs.com/plugins/command-line/ */
        if ( 'yes' === $settings['command_line'] ) {
            $this->scripts[] = 'mdp-prism-command-line-js';
        }

        /** Treeview @see https://prismjs.com/plugins/treeview/ */
        if ( 'treeview' === $settings['language'] ) {
            $this->scripts[] = 'mdp-prism-treeview-js';
        }

        /** Copy to Clipboard Button @see https://prismjs.com/plugins/copy-to-clipboard/ */
        if ( 'yes' === $settings['copy_to_clipboard'] ) {
            $this->scripts[] = 'mdp-prism-copy-to-clipboard-js';
        }

        /** Download Button @see https://prismjs.com/plugins/download-button/ */
        if ( 'yes' === $settings['download_button'] ) {
            $this->scripts[] = 'mdp-prism-download-button-js';
        }

        /** Match braces @see https://prismjs.com/plugins/match-braces/ */
        if (
            ( 'yes' === $settings['match_braces'] ) OR
            ( 'yes' === $settings['rainbow_braces'] )
        ) {
            $this->scripts[] = 'mdp-prism-match-braces-js';
        }

        /** Diff Highlight @see https://prismjs.com/plugins/diff-highlight/ */
        if ( 'yes' === $settings['diff_highlight'] ) {
            $this->scripts[] = 'mdp-prism-diff-js';
            $this->scripts[] = 'mdp-prism-diff-highlight-js';
        }

        /** Frontend Mode. */
        return $this->scripts;

    }

    /**
     * Get style dependencies.
     *
     * Retrieve the list of style dependencies the widget requires.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget styles dependencies.
     **/
    public function get_style_depends() {

        /**
         * Editor Mode.
         * In the edit mode, get_script_depends() does not have access to get_settings() or get_settings_for_display() functions.
         * So, the solution would be, enqueue all the scripts for edit and preview mode, whereas use conditional enqueue for the frontend.
         **/
        if (
            Plugin::$instance->editor->is_edit_mode() ||
            Plugin::$instance->preview->is_preview_mode()
        ) {
            return [
                'mdp-coder-elementor-widget',
                'mdp-prism-line-numbers',
                'mdp-prism-line-highlight',
                'mdp-prism-show-invisibles',
                'mdp-prism-autolinker',
                'mdp-prism-inline-color',
                'mdp-prism-previewers',
                'mdp-prism-wpd',
                'mdp-prism-command-line',
                'mdp-prism-treeview',
                'mdp-prism-match-braces',
                'mdp-prism-diff-highlight',
            ];
        }

        /** Get Widget Settings. */
        $settings = $this->get_settings_for_display();

        /** Core Widget Styles and Scripts. */
        $this->styles[] = 'mdp-coder-elementor-widget';

        /** Line Numbers @see https://prismjs.com/plugins/line-numbers/ */
        if ( 'yes' === $settings['line_numbers'] ) {
            $this->styles[] = 'mdp-prism-line-numbers';
        }

        /** Line Highlight @see https://prismjs.com/plugins/line-highlight/ */
        if ( 'yes' === $settings['line_highlight'] ) {
            $this->styles[] = 'mdp-prism-line-highlight';
        }

        /** Show Invisibles @see https://prismjs.com/plugins/show-invisibles/ */
        if ( 'yes' === $settings['show_invisibles'] ) {
            $this->styles[] = 'mdp-prism-show-invisibles';
        }

        /** Autolinker @see https://prismjs.com/plugins/autolinker/ */
        if ( 'yes' === $settings['autolinker'] ) {
            $this->styles[] = 'mdp-prism-autolinker';
        }

        /** Inline color @see https://prismjs.com/plugins/inline-color/ */
        if ( 'yes' === $settings['inline_color'] ) {
            $this->styles[] = 'mdp-prism-inline-color';
        }

        /** Previewers @see https://prismjs.com/plugins/previewers/ */
        if ( 'yes' === $settings['previewers'] ) {
            $this->styles[] = 'mdp-prism-previewers';
        }

        /** WebPlatform Docs @see https://prismjs.com/plugins/wpd/ */
        if ( 'yes' === $settings['webplatform_docs'] ) {
            $this->styles[] = 'mdp-prism-wpd';
        }

        /** Command Line @see https://prismjs.com/plugins/command-line/ */
        if ( 'yes' === $settings['command_line'] ) {
            $this->styles[] = 'mdp-prism-command-line';
        }

        /** Treeview @see https://prismjs.com/plugins/treeview/ */
        if ( 'treeview' === $settings['language'] ) {
            $this->styles[] = 'mdp-prism-treeview';
        }

        /** Match braces @see https://prismjs.com/plugins/match-braces/ */
        if (
            ( 'yes' === $settings['match_braces'] ) ||
            ( 'yes' === $settings['rainbow_braces'] )
        ) {
            $this->styles[] = 'mdp-prism-match-braces';
        }

        /** Diff Highlight @see https://prismjs.com/plugins/diff-highlight/ */
        if ( 'yes' === $settings['diff_highlight'] ) {
            $this->styles[] = 'mdp-prism-diff-highlight';
        }

        /** Frontend Mode. */
        return $this->styles;

    }

    /**
     * Add the widget controls.
     *
     * @since 1.0.0
     * @access protected
     *
     * @return void with category names
     **/
    protected function register_controls() {

        /** Content Tab. */
        $this->tab_content();

        /** Style Tab. */
        $this->tab_style();

    }

    /**
     * Add widget controls on Content tab.
     *
     * @since 1.0.0
     * @access private
     **/
    private function tab_content() {

        /** Content -> Source Code. */
        $this->section_source();

        /** Content -> Features. */
        $this->section_features();

    }

    /**
     * Add widget controls: Content tab -> Source Code section.
     *
     * @since 1.0.0
     * @access private
     **/
    private function section_features() {

        $this->start_controls_section( 'section_features', [
            'label' => esc_html__( 'Features', 'coder-elementor' ),
            'tab'   => Controls_Manager::TAB_CONTENT
        ] );

        # Line Numbers
        $this->add_control(
            'line_numbers',
            [
                'label'        => esc_html__( 'Line Numbers', 'coder-elementor' ),
                'description'  => esc_html__( 'Line number at the beginning of code lines.', 'coder-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'coder-elementor' ),
                'label_off'    => esc_html__( 'No', 'coder-elementor' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        # Line Highlight
        $this->add_control(
            'line_highlight',
            [
                'label'        => esc_html__( 'Line Highlight', 'coder-elementor' ),
                'description'  => esc_html__( 'Highlights specific lines and/or line ranges.', 'coder-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'coder-elementor' ),
                'label_off'    => esc_html__( 'No', 'coder-elementor' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        # Code URL
        $this->add_control(
            'line_highlight_lines',
            [
                'label'         => esc_html__( 'Lines', 'coder-elementor' ),
                'show_label'    => true,
                'label_block'   => true,
                'type'          => Controls_Manager::TEXT,
                'dynamic'       => ['active' => true],
                'separator'     => 'after',
                'placeholder'   => esc_html__( '1-2, 5, 9-20', 'coder-elementor' ),
                'description'   => esc_html__( '5 - The 5th line', 'coder-elementor' ) . '<br>' .
                    esc_html__( '1-5 - Lines 1 through 5', 'coder-elementor' ) . '<br>' .
                    esc_html__( '1-2, 5, 9-20 - Lines 1 through 2, line 5, lines 9 through 20', 'coder-elementor' ),
                'condition'     => [
                    'line_highlight' => 'yes',
                ],
            ]
        );

        # Show Invisibles
        $this->add_control(
            'show_invisibles',
            [
                'label'        => esc_html__( 'Show Invisibles', 'coder-elementor' ),
                'description'  => esc_html__( 'Show hidden characters such as tabs and line breaks.', 'coder-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'coder-elementor' ),
                'label_off'    => esc_html__( 'No', 'coder-elementor' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        # Autolinker
        $this->add_control(
            'autolinker',
            [
                'label'        => esc_html__( 'Autolinker', 'coder-elementor' ),
                'description'  => esc_html__( 'Converts URLs and emails in code to clickable links. Parses Markdown links in comments.', 'coder-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'coder-elementor' ),
                'label_off'    => esc_html__( 'No', 'coder-elementor' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        # Show Language
        $this->add_control(
            'show_language',
            [
                'label'        => esc_html__( 'Show Language', 'coder-elementor' ),
                'description'  => esc_html__( 'Display the highlighted language in code blocks.', 'coder-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'coder-elementor' ),
                'label_off'    => esc_html__( 'No', 'coder-elementor' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        # Inline Color
        $this->add_control(
            'inline_color',
            [
                'label'        => esc_html__( 'Inline Color', 'coder-elementor' ),
                'description'  => esc_html__( 'Adds a small inline preview for colors in style sheets.', 'coder-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'coder-elementor' ),
                'label_off'    => esc_html__( 'No', 'coder-elementor' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        # Previewers
        $this->add_control(
            'previewers',
            [
                'label'        => esc_html__( 'Previewers', 'coder-elementor' ),
                'description'  => esc_html__( 'Previewers for angles, colors, gradients, easing and time.', 'coder-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'coder-elementor' ),
                'label_off'    => esc_html__( 'No', 'coder-elementor' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        # WebPlatform Docs
        $this->add_control(
            'webplatform_docs',
            [
                'label'        => esc_html__( 'WebPlatform Docs', 'coder-elementor' ),
                'description'  => esc_html__( 'Makes tokens link to WebPlatform.org documentation. The links open in a new tab. This plugin is still in beta.', 'coder-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'coder-elementor' ),
                'label_off'    => esc_html__( 'No', 'coder-elementor' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        # Command Line
        $this->add_control(
            'command_line',
            [
                'label'        => esc_html__( 'Command Line', 'coder-elementor' ),
                'description'  => esc_html__( 'Display a command line with a prompt and, optionally, the output/response from the commands.', 'coder-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'coder-elementor' ),
                'label_off'    => esc_html__( 'No', 'coder-elementor' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        # User
        $this->add_control(
            'command_line_user',
            [
                'label'         => esc_html__( 'User', 'coder-elementor' ),
                'show_label'    => true,
                'label_block'   => true,
                'type'          => Controls_Manager::TEXT,
                'dynamic'       => ['active' => true],
                'placeholder'   => esc_html__( 'root', 'coder-elementor' ),
                'description'   => esc_html__( 'Specify the user name. User root user name to show # or any other name for $.', 'coder-elementor' ),
                'condition'     => [
                    'command_line' => 'yes',
                ],
            ]
        );

        # Host
        $this->add_control(
            'command_line_host',
            [
                'label'         => esc_html__( 'Host', 'coder-elementor' ),
                'show_label'    => true,
                'label_block'   => true,
                'type'          => Controls_Manager::TEXT,
                'dynamic'       => ['active' => true],
                'placeholder'   => esc_html__( 'localhost', 'coder-elementor' ),
                'description'   => esc_html__( 'Specify the host name', 'coder-elementor' ),
                'condition'     => [
                    'command_line' => 'yes',
                ],
            ]
        );

        # Output
        $this->add_control(
            'command_line_output',
            [
                'label'         => esc_html__( 'Output Lines', 'coder-elementor' ),
                'show_label'    => true,
                'label_block'   => true,
                'type'          => Controls_Manager::TEXT,
                'dynamic'       => ['active' => true],
                'separator'     => 'after',
                'placeholder'   => esc_html__( '1-2, 5, 9-20', 'coder-elementor' ),
                'description'   => esc_html__( '5 - The 5th line', 'coder-elementor' ) . '<br>' .
                    esc_html__( '1-5 - Lines 1 through 5', 'coder-elementor' ) . '<br>' .
                    esc_html__( '1-2, 5, 9-20 - Lines 1 through 2, line 5, lines 9 through 20', 'coder-elementor' ),
                'condition'     => [
                    'command_line' => 'yes',
                ],
            ]
        );

        # Copy to Clipboard Button
        $this->add_control(
            'copy_to_clipboard',
            [
                'label'        => esc_html__( 'Copy to Clipboard Button', 'coder-elementor' ),
                'description'  => esc_html__( 'Add a button that copies the code block to the clipboard when clicked.', 'coder-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'coder-elementor' ),
                'label_off'    => esc_html__( 'No', 'coder-elementor' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        # Download Button
        $this->add_control(
            'download_button',
            [
                'label'        => esc_html__( 'Download Button', 'coder-elementor' ),
                'description'  => esc_html__( 'A button in the toolbar of a code block adding a convenient way to download a code file.', 'coder-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'coder-elementor' ),
                'label_off'    => esc_html__( 'No', 'coder-elementor' ),
                'return_value' => 'yes',
                'default'      => 'no',
                'condition'    => [
                    'source' => 'url',
                ],
            ]
        );

        # Match Braces
        $this->add_control(
            'match_braces',
            [
                'label'        => esc_html__( 'Match braces', 'coder-elementor' ),
                'description'  => esc_html__( 'Highlights matching braces.', 'coder-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'coder-elementor' ),
                'label_off'    => esc_html__( 'No', 'coder-elementor' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        # Rainbow Braces
        $this->add_control(
            'rainbow_braces',
            [
                'label'        => esc_html__( 'Rainbow braces', 'coder-elementor' ),
                'description'  => esc_html__( 'Highlights matching braces with different colors.', 'coder-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'coder-elementor' ),
                'label_off'    => esc_html__( 'No', 'coder-elementor' ),
                'return_value' => 'yes',
                'default'      => 'no',
                'condition'    => [
                    'match_braces' => 'yes',
                ],
            ]
        );

        # Diff Highlight
        $this->add_control(
            'diff_highlight',
            [
                'label'        => esc_html__( 'Diff Highlight', 'coder-elementor' ),
                'description'  => esc_html__( 'Highlights the code inside diff blocks.', 'coder-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'coder-elementor' ),
                'label_off'    => esc_html__( 'No', 'coder-elementor' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        $this->end_controls_section();

    }

    /**
     * Add widget controls: Content tab -> Source Code section.
     *
     * @since 1.0.0
     * @access private
     **/
    private function section_source() {

        $this->start_controls_section( 'section_source', [
            'label' => esc_html__( 'Source Code', 'coder-elementor' ),
            'tab'   => Controls_Manager::TAB_CONTENT
        ] );

        # Source
        $this->add_control(
            'source',
            [
                'label'     => esc_html__( 'Source', 'coder-elementor' ),
                'type'      => Controls_Manager::SELECT,
                'options'   => [
                    'editor'    => esc_html__( 'Editor', 'coder-elementor' ),
                    'url'       => esc_html__( 'URL', 'coder-elementor' ),
                ],
                'default'   => 'editor',
                'separator' => 'none',
            ]
        );

        /** @noinspection SpellCheckingInspection */
        $this->add_control(
            'language',
            [
                'label'     => esc_html__( 'Language', 'coder-elementor' ),
                'label_block'   => true,
                'type'      => Controls_Manager::SELECT2,
                'multiple'  => false,
                'options' => [
                    'markup'                   => esc_html__( 'Markup ( HTML, XML, SVG, MathML )', 'coder-elementor' ),
                    'css'                      => esc_html__( 'CSS', 'coder-elementor' ),
                    'clike'                    => esc_html__( 'C-like', 'coder-elementor' ),
                    'javascript'               => esc_html__( 'JavaScript', 'coder-elementor' ),
                    'php'                      => esc_html__( 'PHP', 'coder-elementor' ),
                    'phpdoc'                   => esc_html__( 'PHPDoc', 'coder-elementor' ),
                    'treeview'                 => esc_html__( 'Treeview', 'coder-elementor' ),
                    'abap'                     => esc_html__( 'ABAP', 'coder-elementor' ),
                    'abnf'                     => esc_html__( 'Augmented Backus–Naur form', 'coder-elementor' ),
                    'actionscript'             => esc_html__( 'ActionScript', 'coder-elementor' ),
                    'ada'                      => esc_html__( 'Ada', 'coder-elementor' ),
                    'antlr4'                   => esc_html__( 'ANTLR4', 'coder-elementor' ),
                    'apacheconf'               => esc_html__( 'Apache Configuration', 'coder-elementor' ),
                    'apl'                      => esc_html__( 'APL', 'coder-elementor' ),
                    'applescript'              => esc_html__( 'AppleScript', 'coder-elementor' ),
                    'aql'                      => esc_html__( 'AQL', 'coder-elementor' ),
                    'arduino'                  => esc_html__( 'Arduino', 'coder-elementor' ),
                    'arff'                     => esc_html__( 'ARFF', 'coder-elementor' ),
                    'asciidoc'                 => esc_html__( 'AsciiDoc', 'coder-elementor' ),
                    'asm6502'                  => esc_html__( '6502 Assembly', 'coder-elementor' ),
                    'aspnet'                   => esc_html__( 'ASP.NET (C#)', 'coder-elementor' ),
                    'autohotkey'               => esc_html__( 'AutoHotkey', 'coder-elementor' ),
                    'autoit'                   => esc_html__( 'AutoIt', 'coder-elementor' ),
                    'bash'                     => esc_html__( 'Bash, Shell', 'coder-elementor' ),
                    'basic'                    => esc_html__( 'BASIC', 'coder-elementor' ),
                    'batch'                    => esc_html__( 'Batch', 'coder-elementor' ),
                    'bbcode'                   => esc_html__( 'BBcode, Shortcode', 'coder-elementor' ),
                    'bison'                    => esc_html__( 'Bison', 'coder-elementor' ),
                    'bnf'                      => esc_html__( 'Backus–Naur form', 'coder-elementor' ),
                    'brainfuck'                => esc_html__( 'Brainfuck', 'coder-elementor' ),
                    'brightscript'             => esc_html__( 'BrightScript', 'coder-elementor' ),
                    'bro'                      => esc_html__( 'Bro', 'coder-elementor' ),
                    'c'                        => esc_html__( 'C', 'coder-elementor' ),
                    'concurnas'                => esc_html__( 'Concurnas', 'coder-elementor' ),
                    'csharp'                   => esc_html__( 'C#', 'coder-elementor' ),
                    'cpp'                      => esc_html__( 'C++', 'coder-elementor' ),
                    'cil'                      => esc_html__( 'CIL', 'coder-elementor' ),
                    'coffeescript'             => esc_html__( 'CoffeeScript', 'coder-elementor' ),
                    'cmake'                    => esc_html__( 'CMake', 'coder-elementor' ),
                    'clojure'                  => esc_html__( 'Clojure', 'coder-elementor' ),
                    'crystal'                  => esc_html__( 'Crystal', 'coder-elementor' ),
                    'csp'                      => esc_html__( 'Content-Security-Policy', 'coder-elementor' ),
                    'css-extras'               => esc_html__( 'CSS Extras', 'coder-elementor' ),
                    'd'                        => esc_html__( 'D', 'coder-elementor' ),
                    'dart'                     => esc_html__( 'Dart', 'coder-elementor' ),
                    'dax'                      => esc_html__( 'DAX', 'coder-elementor' ),
                    'diff'                     => esc_html__( 'Diff', 'coder-elementor' ),
                    'django'                   => esc_html__( 'Django/Jinja2', 'coder-elementor' ),
                    'dns-zone-file'            => esc_html__( 'DNS zone file', 'coder-elementor' ),
                    'docker'                   => esc_html__( 'Docker', 'coder-elementor' ),
                    'ebnf'                     => esc_html__( 'Extended Backus–Naur form', 'coder-elementor' ),
                    'eiffel'                   => esc_html__( 'Eiffel', 'coder-elementor' ),
                    'ejs'                      => esc_html__( 'EJS', 'coder-elementor' ),
                    'elixir'                   => esc_html__( 'Elixir', 'coder-elementor' ),
                    'elm'                      => esc_html__( 'Elm', 'coder-elementor' ),
                    'etlua'                    => esc_html__( 'Embedded Lua templating', 'coder-elementor' ),
                    'erb'                      => esc_html__( 'ERB', 'coder-elementor' ),
                    'erlang'                   => esc_html__( 'Erlang', 'coder-elementor' ),
                    'excel-formula'            => esc_html__( 'Excel Formula', 'coder-elementor' ),
                    'fsharp'                   => esc_html__( 'F#', 'coder-elementor' ),
                    'factor'                   => esc_html__( 'Factor', 'coder-elementor' ),
                    'firestore-security-rules' => esc_html__( 'Firestore security rules', 'coder-elementor' ),
                    'flow'                     => esc_html__( 'Flow', 'coder-elementor' ),
                    'fortran'                  => esc_html__( 'Fortran', 'coder-elementor' ),
                    'ftl'                      => esc_html__( 'FreeMarker Template Language', 'coder-elementor' ),
                    'gcode'                    => esc_html__( 'G-code', 'coder-elementor' ),
                    'gdscript'                 => esc_html__( 'GDScript', 'coder-elementor' ),
                    'gedcom'                   => esc_html__( 'GEDCOM', 'coder-elementor' ),
                    'gherkin'                  => esc_html__( 'Gherkin', 'coder-elementor' ),
                    'git'                      => esc_html__( 'Git', 'coder-elementor' ),
                    'glsl'                     => esc_html__( 'GLSL', 'coder-elementor' ),
                    'gml'                      => esc_html__( 'GameMaker Language', 'coder-elementor' ),
                    'go'                       => esc_html__( 'Go', 'coder-elementor' ),
                    'graphql'                  => esc_html__( 'GraphQL', 'coder-elementor' ),
                    'groovy'                   => esc_html__( 'Groovy', 'coder-elementor' ),
                    'haml'                     => esc_html__( 'Haml', 'coder-elementor' ),
                    'handlebars'               => esc_html__( 'Handlebars', 'coder-elementor' ),
                    'haskell'                  => esc_html__( 'Haskell', 'coder-elementor' ),
                    'haxe'                     => esc_html__( 'Haxe', 'coder-elementor' ),
                    'hcl'                      => esc_html__( 'HCL', 'coder-elementor' ),
                    'http'                     => esc_html__( 'HTTP', 'coder-elementor' ),
                    'hpkp'                     => esc_html__( 'HTTP Public-Key-Pins', 'coder-elementor' ),
                    'hsts'                     => esc_html__( 'HTTP Strict-Transport-Security', 'coder-elementor' ),
                    'ichigojam'                => esc_html__( 'IchigoJam', 'coder-elementor' ),
                    'icon'                     => esc_html__( 'Icon', 'coder-elementor' ),
                    'iecst'                    => esc_html__( 'Structured Text (IEC 61131-3)', 'coder-elementor' ),
                    'inform7'                  => esc_html__( 'Inform 7', 'coder-elementor' ),
                    'ini'                      => esc_html__( 'Ini', 'coder-elementor' ),
                    'io'                       => esc_html__( 'Io', 'coder-elementor' ),
                    'j'                        => esc_html__( 'J', 'coder-elementor' ),
                    'java'                     => esc_html__( 'Java', 'coder-elementor' ),
                    'javadoc'                  => esc_html__( 'JavaDoc', 'coder-elementor' ),
                    'javadoclike'              => esc_html__( 'JavaDoc-like', 'coder-elementor' ),
                    'javastacktrace'           => esc_html__( 'Java stack trace', 'coder-elementor' ),
                    'jolie'                    => esc_html__( 'Jolie', 'coder-elementor' ),
                    'jq'                       => esc_html__( 'JQ', 'coder-elementor' ),
                    'jsdoc'                    => esc_html__( 'JSDoc', 'coder-elementor' ),
                    'js-extras'                => esc_html__( 'JS Extras', 'coder-elementor' ),
                    'js-templates'             => esc_html__( 'JS Templates', 'coder-elementor' ),
                    'json'                     => esc_html__( 'JSON', 'coder-elementor' ),
                    'jsonp'                    => esc_html__( 'JSONP', 'coder-elementor' ),
                    'json5'                    => esc_html__( 'JSON5', 'coder-elementor' ),
                    'julia'                    => esc_html__( 'Julia', 'coder-elementor' ),
                    'keyman'                   => esc_html__( 'Keyman', 'coder-elementor' ),
                    'kotlin'                   => esc_html__( 'Kotlin', 'coder-elementor' ),
                    'latex'                    => esc_html__( 'LaTeX', 'coder-elementor' ),
                    'latte'                    => esc_html__( 'Latte', 'coder-elementor' ),
                    'less'                     => esc_html__( 'Less', 'coder-elementor' ),
                    'lilypond'                 => esc_html__( 'LilyPond', 'coder-elementor' ),
                    'liquid'                   => esc_html__( 'Liquid', 'coder-elementor' ),
                    'lisp'                     => esc_html__( 'Lisp', 'coder-elementor' ),
                    'livescript'               => esc_html__( 'LiveScript', 'coder-elementor' ),
                    'llvm'                     => esc_html__( 'LLVM IR', 'coder-elementor' ),
                    'lolcode'                  => esc_html__( 'LOLCODE', 'coder-elementor' ),
                    'lua'                      => esc_html__( 'Lua', 'coder-elementor' ),
                    'makefile'                 => esc_html__( 'Makefile', 'coder-elementor' ),
                    'markdown'                 => esc_html__( 'Markdown', 'coder-elementor' ),
                    'markup-templating'        => esc_html__( 'Markup templating', 'coder-elementor' ),
                    'matlab'                   => esc_html__( 'MATLAB', 'coder-elementor' ),
                    'mel'                      => esc_html__( 'MEL', 'coder-elementor' ),
                    'mizar'                    => esc_html__( 'Mizar', 'coder-elementor' ),
                    'monkey'                   => esc_html__( 'Monkey', 'coder-elementor' ),
                    'moonscript'               => esc_html__( 'MoonScript', 'coder-elementor' ),
                    'n1ql'                     => esc_html__( 'N1QL', 'coder-elementor' ),
                    'n4js'                     => esc_html__( 'N4JS', 'coder-elementor' ),
                    'nand2tetris-hdl'          => esc_html__( 'Nand To Tetris HDL', 'coder-elementor' ),
                    'nasm'                     => esc_html__( 'NASM', 'coder-elementor' ),
                    'neon'                     => esc_html__( 'NEON', 'coder-elementor' ),
                    'nginx'                    => esc_html__( 'nginx', 'coder-elementor' ),
                    'nim'                      => esc_html__( 'Nim', 'coder-elementor' ),
                    'nix'                      => esc_html__( 'Nix', 'coder-elementor' ),
                    'nsis'                     => esc_html__( 'NSIS', 'coder-elementor' ),
                    'objectivec'               => esc_html__( 'Objective-C', 'coder-elementor' ),
                    'ocaml'                    => esc_html__( 'OCaml', 'coder-elementor' ),
                    'opencl'                   => esc_html__( 'OpenCL', 'coder-elementor' ),
                    'oz'                       => esc_html__( 'Oz', 'coder-elementor' ),
                    'parigp'                   => esc_html__( 'PARI/GP', 'coder-elementor' ),
                    'parser'                   => esc_html__( 'Parser', 'coder-elementor' ),
                    'pascal'                   => esc_html__( 'Pascal', 'coder-elementor' ),
                    'pascaligo'                => esc_html__( 'Pascaligo', 'coder-elementor' ),
                    'pcaxis'                   => esc_html__( 'PC-Axis', 'coder-elementor' ),
                    'perl'                     => esc_html__( 'Perl', 'coder-elementor' ),
                    'plsql'                    => esc_html__( 'PL/SQL', 'coder-elementor' ),
                    'powerquery'               => esc_html__( 'PowerQuery', 'coder-elementor' ),
                    'powershell'               => esc_html__( 'PowerShell', 'coder-elementor' ),
                    'processing'               => esc_html__( 'Processing', 'coder-elementor' ),
                    'prolog'                   => esc_html__( 'Prolog', 'coder-elementor' ),
                    'properties'               => esc_html__( '.properties', 'coder-elementor' ),
                    'protobuf'                 => esc_html__( 'Protocol Buffers', 'coder-elementor' ),
                    'pug'                      => esc_html__( 'Pug', 'coder-elementor' ),
                    'puppet'                   => esc_html__( 'Puppet', 'coder-elementor' ),
                    'pure'                     => esc_html__( 'Pure', 'coder-elementor' ),
                    'python'                   => esc_html__( 'Python', 'coder-elementor' ),
                    'q'                        => esc_html__( 'Q (kdb+ database)', 'coder-elementor' ),
                    'qml'                      => esc_html__( 'QML', 'coder-elementor' ),
                    'qore'                     => esc_html__( 'Qore', 'coder-elementor' ),
                    'r'                        => esc_html__( 'R', 'coder-elementor' ),
                    'jsx'                      => esc_html__( 'React JSX', 'coder-elementor' ),
                    'tsx'                      => esc_html__( 'React TSX', 'coder-elementor' ),
                    'renpy'                    => esc_html__( 'Ren\'py', 'coder-elementor' ),
                    'reason'                   => esc_html__( 'Reason', 'coder-elementor' ),
                    'regex'                    => esc_html__( 'Regex', 'coder-elementor' ),
                    'rest'                     => esc_html__( 'reST (reStructuredText)', 'coder-elementor' ),
                    'rip'                      => esc_html__( 'Rip', 'coder-elementor' ),
                    'roboconf'                 => esc_html__( 'Roboconf', 'coder-elementor' ),
                    'robotframework'           => esc_html__( 'Robot Framework', 'coder-elementor' ),
                    'ruby'                     => esc_html__( 'Ruby', 'coder-elementor' ),
                    'rust'                     => esc_html__( 'Rust', 'coder-elementor' ),
                    'sas'                      => esc_html__( 'SAS', 'coder-elementor' ),
                    'sass'                     => esc_html__( 'Sass (Sass)', 'coder-elementor' ),
                    'scss'                     => esc_html__( 'Sass (Scss)', 'coder-elementor' ),
                    'scala'                    => esc_html__( 'Scala', 'coder-elementor' ),
                    'scheme'                   => esc_html__( 'Scheme', 'coder-elementor' ),
                    'shell-session'            => esc_html__( 'Shell session', 'coder-elementor' ),
                    'smalltalk'                => esc_html__( 'Smalltalk', 'coder-elementor' ),
                    'smarty'                   => esc_html__( 'Smarty', 'coder-elementor' ),
                    'solidity'                 => esc_html__( 'Solidity (Ethereum)', 'coder-elementor' ),
                    'solution-file'            => esc_html__( 'Solution file', 'coder-elementor' ),
                    'soy'                      => esc_html__( 'Soy (Closure Template)', 'coder-elementor' ),
                    'sparql'                   => esc_html__( 'SPARQL', 'coder-elementor' ),
                    'splunk-spl'               => esc_html__( 'Splunk SPL', 'coder-elementor' ),
                    'sqf'                      => esc_html__( 'SQF: Status Quo Function (Arma 3)', 'coder-elementor' ),
                    'sql'                      => esc_html__( 'SQL', 'coder-elementor' ),
                    'stylus'                   => esc_html__( 'Stylus', 'coder-elementor' ),
                    'swift'                    => esc_html__( 'Swift', 'coder-elementor' ),
                    'tap'                      => esc_html__( 'TAP', 'coder-elementor' ),
                    'tcl'                      => esc_html__( 'Tcl', 'coder-elementor' ),
                    'textile'                  => esc_html__( 'Textile', 'coder-elementor' ),
                    'toml'                     => esc_html__( 'TOML', 'coder-elementor' ),
                    'tt2'                      => esc_html__( 'Template Toolkit 2', 'coder-elementor' ),
                    'turtle'                   => esc_html__( 'Turtle', 'coder-elementor' ),
                    'twig'                     => esc_html__( 'Twig', 'coder-elementor' ),
                    'typescript'               => esc_html__( 'TypeScript', 'coder-elementor' ),
                    't4-cs'                    => esc_html__( 'T4 Text Templates (C#)', 'coder-elementor' ),
                    't4-vb'                    => esc_html__( 'T4 Text Templates (VB)', 'coder-elementor' ),
                    't4-templating'            => esc_html__( 'T4 templating', 'coder-elementor' ),
                    'vala'                     => esc_html__( 'Vala', 'coder-elementor' ),
                    'vbnet'                    => esc_html__( 'VB.Net', 'coder-elementor' ),
                    'velocity'                 => esc_html__( 'Velocity', 'coder-elementor' ),
                    'verilog'                  => esc_html__( 'Verilog', 'coder-elementor' ),
                    'vhdl'                     => esc_html__( 'VHDL', 'coder-elementor' ),
                    'vim'                      => esc_html__( 'vim', 'coder-elementor' ),
                    'visual-basic'             => esc_html__( 'Visual Basic', 'coder-elementor' ),
                    'wasm'                     => esc_html__( 'WebAssembly', 'coder-elementor' ),
                    'wiki'                     => esc_html__( 'Wiki markup', 'coder-elementor' ),
                    'xeora'                    => esc_html__( 'Xeora', 'coder-elementor' ),
                    'xojo'                     => esc_html__( 'Xojo (REALbasic)', 'coder-elementor' ),
                    'xquery'                   => esc_html__( 'XQuery', 'coder-elementor' ),
                    'yaml'                     => esc_html__( 'YAML', 'coder-elementor' ),
                    'zig'                      => esc_html__( 'Zig', 'coder-elementor' ),
                ],
                'default' => ['php'],
            ]
        );

        # Code Editor
        $this->add_control(
            'code_editor',
            [
                'label'         => esc_html__( 'Code Editor', 'coder-elementor' ),
                'show_label'    => false,
                'label_block'   => true,
                'type'          => Controls_Manager::TEXTAREA,
                'default'       => '<' . '?' . 'php' . PHP_EOL .  esc_html__( 'echo Hello World!; ', 'coder-elementor' ) . PHP_EOL . '?' . '>',
                'placeholder'   => esc_html__( 'Enter Your Code Here', 'coder-elementor' ),
                'condition'     => [
                    'source' => 'editor',
                ],
            ]
        );

        # Code URL
        $this->add_control(
            'code_url',
            [
                'label'         => esc_html__( 'Code URL', 'coder-elementor' ),
                'show_label'    => false,
                'label_block'   => true,
                'type'          => Controls_Manager::TEXT,
                'dynamic'       => ['active' => true],
                'placeholder'   => esc_html__( '/path/to/source-file.js', 'coder-elementor' ),
                'description'   => esc_html__( 'Files are fetched with XMLHttpRequest. If the file is on a different origin, fetching it will fail, unless CORS is enabled on that website.', 'coder-elementor' ),
                'condition'     => [
                    'source' => 'url',
                ],
            ]
        );

        $this->end_controls_section();

    }

    /**
     * Add widget controls: Style -> Code Block section
     *
     * @since 1.0.0
     * @access private
     **/
    private function section_code_block() {

        $this->start_controls_section( 'section_code_block', [
            'label' => esc_html__( 'Code Block', 'coder-elementor' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ] );

        $themes = [
            'default'           => esc_html__( 'Default', 'coder-elementor' ),
            'none'              => esc_html__( 'None', 'coder-elementor' ),
            'coy'               => esc_html__( 'Coy', 'coder-elementor' ),
            'dark'              => esc_html__( 'Dark', 'coder-elementor' ),
            'funky'             => esc_html__( 'Funky', 'coder-elementor' ),
            'okaidia'           => esc_html__( 'Okaidia', 'coder-elementor' ),
            'solarizedlight'    => esc_html__( 'Solarized Light', 'coder-elementor' ),
            'tomorrow'          => esc_html__( 'Tomorrow Night', 'coder-elementor' ),
            'twilight'          => esc_html__( 'Twilight', 'coder-elementor' ),
            'a11y-dark'         => esc_html__( 'A11Y Dark', 'coder-elementor' ),
            'atom-dark'         => esc_html__( 'Atom Dark', 'coder-elementor' ),
            'base16-ateliersulphurpool.light' => esc_html__( 'Base16 Atelier Sulphurpool Light', 'coder-elementor' ),
            'cb'               => esc_html__( 'CB', 'coder-elementor' ),
            'darcula'          => esc_html__( 'Darcula', 'coder-elementor' ),
            'dracula'          => esc_html__( 'Dracula', 'coder-elementor' ),
            'duotone-dark'     => esc_html__( 'Duotone Dark', 'coder-elementor' ),
            'duotone-earth'    => esc_html__( 'Duotone Earth', 'coder-elementor' ),
            'duotone-forest'   => esc_html__( 'Duotone Forest', 'coder-elementor' ),
            'duotone-light'    => esc_html__( 'Duotone Light', 'coder-elementor' ),
            'duotone-sea'      => esc_html__( 'Duotone Sea', 'coder-elementor' ),
            'duotone-space'    => esc_html__( 'Duotone Space', 'coder-elementor' ),
            'ghcolors'         => esc_html__( 'GHColors', 'coder-elementor' ),
            'hopscotch'        => esc_html__( 'Hopscotch', 'coder-elementor' ),
            'material-dark'    => esc_html__( 'Material Dark', 'coder-elementor' ),
            'material-light'   => esc_html__( 'Material Light', 'coder-elementor' ),
            'material-oceanic' => esc_html__( 'Material Oceanic', 'coder-elementor' ),
            'nord'             => esc_html__( 'Nord', 'coder-elementor' ),
            'pojoaque'         => esc_html__( 'Pojoaque', 'coder-elementor' ),
            'shades-of-purple' => esc_html__( 'Shades of Purple', 'coder-elementor' ),
            'synthwave84'      => esc_html__( 'Synthwave \'84', 'coder-elementor' ),
            'vs'               => esc_html__( 'VS', 'coder-elementor' ),
            'vsc-dark-plus'    => esc_html__( 'VSC Dark Plus', 'coder-elementor' ),
            'xonokai'          => esc_html__( 'Xonokai', 'coder-elementor' ),
        ];

        # Theme
        $this->add_control(
            'theme',
            [
                'label'     => esc_html__( 'Theme', 'coder-elementor' ),
                'type'      => Controls_Manager::SELECT,
                'options'   => $themes,
                'default'   => 'default',
                'separator' => 'none',
            ]
        );

        # Dark/Light Mode
        $this->add_control(
            'dark_light_mode',
            [
                'label'        => esc_html__( 'Dark/Light Mode', 'coder-elementor' ),
                'description'  => esc_html__( 'Detect if the user has requested the system use a light or dark color theme.', 'coder-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'coder-elementor' ),
                'label_off'    => esc_html__( 'No', 'coder-elementor' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        # Theme
        $this->add_control(
            'dark_theme',
            [
                'label'     => esc_html__( 'Dark Mode Theme', 'coder-elementor' ),
                'type'      => Controls_Manager::SELECT,
                'options'   => $themes,
                'default'   => 'default',
                'separator' => 'none',
                'condition'     => [
                    'dark_light_mode' => 'yes',
                ],
            ]
        );

        # Code Typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'code_typography',
                'selector' => "{{WRAPPER}} .mdp-coder-elementor-box pre > code",
                'fields_options' => [
	                'font_size' => [
		                'size_units' => ['em'],
		                'range' => [
			                'em' => [
				                'min' => 1,
				                'max' => 10,
				                'step' => 0.1
			                ],
                        ],
		                'default'   => [
			                'unit' => 'em',
		                ],
		                'tablet_default' => [
			                'unit' => 'em',
		                ],
		                'mobile_default' => [
			                'unit' => 'em',
		                ],
	                ],
                ],
            ]
        );

        # Background
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'              => 'code_block_background',
                'types'             => [ 'classic', 'gradient' ],
                'selector'          => '{{WRAPPER}} .mdp-coder-elementor-box pre, {{WRAPPER}} .mdp-coder-elementor-box pre[class*="language-"]',
            ]
        );

        $this->add_responsive_control(
            'code_height',
            [
                'label'     => esc_html__( 'Max Height', 'coder-elementor' ),
                'separator' => 'before',
                'type'      => Controls_Manager::SLIDER,
                'default'   => [
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'unit' => 'px',
                ],
                'size_units' => [ 'em', 'px', 'vh' ],
                'range' => [
                    'em' => [
                        'min' => 1,
                        'max' => 20,
                        'step' => 0.1
                    ],
                    'px' => [
                        'min' => 10,
                        'max' => 1000,
                    ],
                    'vh' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .mdp-coder-elementor-box pre' => 'max-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        # Margin
        $this->add_responsive_control(
            'code_block_margin',
            [
                'label'         => esc_html__( 'Margin', 'coder-elementor' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%' ],
                'selectors'     => [
                    '{{WRAPPER}} .mdp-coder-elementor-box pre' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        # Padding
        $this->add_responsive_control(
            'code_block_padding',
            [
                'label'         => esc_html__( 'Padding', 'coder-elementor' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%' ],
                'selectors'     => [
                    '{{WRAPPER}} .mdp-coder-elementor-box pre' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        # Border
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'      => 'code_block_border',
                'selector'  => '{{WRAPPER}} .mdp-coder-elementor-box pre',
                'separator' => 'before',
            ]
        );

        # Border Radius
        $this->add_control(
            'code_block_radius',
            [
                'label'         => esc_html__( 'Border Radius', 'coder-elementor' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%' ],
                'selectors'     => [
                    '{{WRAPPER}} .mdp-coder-elementor-box pre' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'after',
            ]
        );

        # Box Shadow
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'code_block_box_shadow',
                'selector' => '{{WRAPPER}} .mdp-coder-elementor-box pre',
            ]
        );

        $this->end_controls_section();

    }

    /**
     * Add widget controls: Style -> Copy section
     *
     * @since 1.0.0
     * @access private
     **/
    private function section_language() {

        $this->start_controls_section( 'section_language', [
            'label' => esc_html__( 'Language mark', 'coder-elementor' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_language' => 'yes' ]
        ] );

        # Always visible
        $this->add_control(
            'language_always',
            [
                'label'        => esc_html__( 'Always visible', 'coder-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'coder-elementor' ),
                'label_off'    => esc_html__( 'No', 'coder-elementor' ),
                'return_value' => '1',
                'default'      => '0',
                'selectors' => [
                    '{{WRAPPER}} div.code-toolbar>.toolbar span' => 'opacity: {{VALUE}}',
                ],
                'separator' => 'after'
            ]
        );

        # Margin
        $this->add_responsive_control(
            'language_margin',
            [
                'label'         => esc_html__( 'Margin', 'coder-elementor' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%' ],
                'selectors'     => [
                    '{{WRAPPER}} div.code-toolbar>.toolbar span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        # Padding
        $this->add_responsive_control(
            'language_padding',
            [
                'label'         => esc_html__( 'Padding', 'coder-elementor' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%' ],
                'selectors'     => [
                    '{{WRAPPER}} div.code-toolbar>.toolbar span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'after',
            ]
        );

        # Typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'language_typography',
                'selector' => '{{WRAPPER}} div.code-toolbar>.toolbar span',
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_PRIMARY
                ],
            ]
        );

        # Color
        $this->add_control(
            'language_color',
            [
                'label' => __( 'Ink Color', 'plugin-domain' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} div.code-toolbar>.toolbar span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} div.code-toolbar>.toolbar span:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        # Background
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'language_background',
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} div.code-toolbar>.toolbar span',
            ]
        );

        #Border
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'language_border',
                'selector' => '{{WRAPPER}} div.code-toolbar>.toolbar span',
                'separator' => 'before'
            ]
        );

        # Border radius
        $this->add_control(
            'language_radius',
            [
                'label'         => esc_html__( 'Border Radius', 'coder-elementor' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%' ],
                'selectors'     => [
                    '{{WRAPPER}} div.code-toolbar>.toolbar span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'after'
            ]
        );

        # Box Shadow
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'language_shadow',
                'selector' => '{{WRAPPER}} div.code-toolbar>.toolbar span',
            ]
        );

        $this->end_controls_section();

    }

    /**
     * Add widget controls: Style -> Copy section
     *
     * @since 1.0.0
     * @access private
     **/
    private function section_copy() {

        $this->start_controls_section( 'section_copy', [
            'label' => esc_html__( 'Copy button', 'coder-elementor' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            'condition' => [ 'copy_to_clipboard' => 'yes' ]
        ] );

        # Always visible
        $this->add_control(
            'copy_always',
            [
                'label'        => esc_html__( 'Always visible', 'coder-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'coder-elementor' ),
                'label_off'    => esc_html__( 'No', 'coder-elementor' ),
                'return_value' => '1',
                'default'      => '0',
                'selectors' => [
                    '{{WRAPPER}} div.code-toolbar>.toolbar button' => 'opacity: {{VALUE}}',
                ],
                'separator' => 'after'
            ]
        );

        # Margin
        $this->add_responsive_control(
            'copy_margin',
            [
                'label'         => esc_html__( 'Margin', 'coder-elementor' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%' ],
                'selectors'     => [
                    '{{WRAPPER}} div.code-toolbar>.toolbar button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        # Padding
        $this->add_responsive_control(
            'copy_padding',
            [
                'label'         => esc_html__( 'Padding', 'coder-elementor' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%' ],
                'selectors'     => [
                    '{{WRAPPER}} div.code-toolbar>.toolbar button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'after',
            ]
        );

        # Height
        $this->add_control(
            'copy_height',
            [
                'label'     => esc_html__( 'Icon Height', 'coder-elementor' ),
                'type'      => Controls_Manager::SLIDER,
                'default'   => [
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} div.code-toolbar>.toolbar button svg' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        # Color
        $this->add_control(
            'copy_color',
            [
                'label' => __( 'Ink Color', 'plugin-domain' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} div.code-toolbar>.toolbar button path' => 'fill: {{VALUE}}',
                ],
            ]
        );

        # Background
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'copy_background',
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} div.code-toolbar>.toolbar button',
            ]
        );

        #Border
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'copy_border',
                'selector' => '{{WRAPPER}} div.code-toolbar>.toolbar button',
                'separator' => 'before'
            ]
        );

        # Border radius
        $this->add_control(
            'copy_radius',
            [
                'label'         => esc_html__( 'Border Radius', 'coder-elementor' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%' ],
                'selectors'     => [
                    '{{WRAPPER}} div.code-toolbar>.toolbar button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'after'
            ]
        );

        # Box Shadow
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'copy_shadow',
                'selector' => '{{WRAPPER}} div.code-toolbar>.toolbar button',
            ]
        );

        $this->end_controls_section();

    }

    /**
     * Add widget controls on Style tab.
     *
     * @since 1.0.0
     * @access private
     **/
    private function tab_style() {

        /** Style -> Code Block. */
        $this->section_code_block();

        /** Style -> Language */
        $this->section_language();

        /** Style -> Copy  */
        $this->section_copy();

    }

    /**
     * Render Frontend Output. Generate the final HTML on the frontend.
     *
     * @since 1.0.0
     * @access protected
     **/
    protected function render() {

        $id = 'mdp-coder-' . $this->get_id();

        /** Get Widget Settings. */
        $settings = $this->get_settings_for_display();

        /** Fix language when nothing selected. */
        $settings['language'] = $this->fix_language( $settings['language'] );

        $light_theme = $settings['theme'];
        $dark_theme = $light_theme;
        if ( 'yes' === $settings['dark_light_mode'] ) {
            $dark_theme = $settings['dark_theme'];
        }

        ?>
        <!-- Start Coder for Elementor WordPress Plugin -->
        <div
            id="<?php esc_attr_e( $id ); ?>"
            class="mdp-coder-elementor-box"
            data-theme="mdp-theme-<?php esc_attr_e( $light_theme ); ?>"
            data-dark-theme="mdp-theme-<?php esc_attr_e( $dark_theme ); ?>"
        >
            <?php if ( 'editor' === $settings['source'] ) : ?>

                <?php $this->render_from_editor( $settings ); // Render from Editor. ?>

            <?php elseif ( 'url' === $settings['source'] ) : ?>

                <?php $this->render_from_url( $settings ); // Render from Editor. ?>

            <?php endif; ?>
        </div>
        <?php $this->render_js(); // Render JavaScript. ?>
        <!-- End Coder for Elementor WordPress Plugin -->

        <?php

    }

    private function render_from_url( $settings ) {

        if ( strlen( trim( $settings['code_url'] ) ) < 3 ) {

            ?><pre class="language-none"><?php esc_html_e( 'Enter a valid file link.', 'coder-elementor' ); ?></pre><?php

        } else {

            ?><pre <?php $this->render_attributes( $settings ); ?> data-src="<?php esc_attr_e( $settings['code_url'] ); ?>"></pre><?php

        }

    }

    private function render_from_editor( $settings ) {

        ?><pre <?php $this->render_attributes( $settings ); ?>><code><?php
            echo htmlentities( $this->get_settings_for_display( 'code_editor' ) );
            ?></code></pre><?php

    }

    /**
     * Render classes for PrismJS plugins.
     *
     * @param array $settings - Current Widget Settings.
     *
     * @since  1.0.0
     * @access protected
     *
     * @return string
     **/
    private function get_classes( $settings ) {

        $classes = [];

        /** Language to highlight. */
        if ( 'yes' !== $settings['diff_highlight'] ) {
            $classes[] = "language-{$settings['language']}";
        }

        /** Plugin Line Numbers. */
        if ( 'yes' === $settings['line_numbers'] ) {
            $classes[] = 'line-numbers';
        }

        /** Plugin Show Invisibles. */
        if ( 'yes' === $settings['show_invisibles'] ) {
            $classes[] = 'show-invisibles';
        }

        /** Plugin Autolinker. */
        if ( 'yes' === $settings['autolinker'] ) {
            $classes[] = 'autolinker';
        }

        /** Plugin Show Language. */
        if ( 'yes' === $settings['show_language'] ) {
            $classes[] = 'show-language';
        }

        /** Plugin Inline Color. */
        if ( 'yes' === $settings['inline_color'] ) {
            $classes[] = 'inline-color';
        }

        /** Plugin WebPlatform Docs. */
        if ( 'yes' === $settings['webplatform_docs'] ) {
            $classes[] = 'webplatform-docs';
        }

        /** Plugin Command Line. */
        if ( 'yes' === $settings['command_line'] ) {
            $classes[] = 'command-line';
        }

        /** Copy to Clipboard Button. */
        if ( 'yes' === $settings['copy_to_clipboard'] ) {
            $classes[] = 'copy-to-clipboard';
        }

        /** Match braces. */
        if ( 'yes' === $settings['match_braces'] ) {
            $classes[] = 'match-braces';
        }

        /** Rainbow braces. */
        if ( 'yes' === $settings['rainbow_braces'] ) {
            $classes[] = 'rainbow-braces';
        }

        /** Diff Highlight. */
        if ( 'yes' === $settings['diff_highlight'] ) {
            $classes[] = "language-diff-{$settings['language']}";
            $classes[] = 'diff-highlight';
        }

        return implode ( ' ', $classes );

    }

    /**
     * Render attributes for PrismJS plugins.
     *
     * @param array $settings - Current Widget Settings.
     *
     * @since  1.0.0
     * @access protected
     **/
    private function render_attributes( $settings ) {

        $atts = [];

        /** Classes. */
        $atts['class'] = $this->get_classes( $settings );

        /** Plugin Line Highlight. */
        if ( 'yes' === $settings['line_highlight'] ) {
            $atts['data-line'] = $settings['line_highlight_lines'];
        }

        /** Plugin Previewers. */
        if ( 'yes' === $settings['previewers'] ) {
            $atts['data-previewers'] = 'gradient angle color easing time';
        } else {
            $atts['data-previewers'] = '';
        }

        /** Plugin Command Line. */
        if ( 'yes' === $settings['command_line'] ) {
            $atts['data-user'] = $settings['command_line_user'];
            $atts['data-host'] = $settings['command_line_host'];
            $atts['data-output'] = $settings['command_line_output'];
        }

        /** Download Button. */
        if ( 'yes' === $settings['download_button'] ) {
            $atts['data-download-link'] = 'true';
        }

        /** Print attributes. */
        foreach ( $atts as $att_name => $att_value ) {

            esc_attr_e( $att_name ); ?>="<?php esc_attr_e( $att_value ); ?>"<?php

        }

    }

    /**
     * Render JavaScript to init code blocks on the frontend.
     *
     * @since 1.0.0
     * @access protected
     **/
    private function render_js() {

        /** Path to prism-js languages folder. */
        $lang_path = UnityPlugin::get_url() . 'js/prism/components/';

        ?>
        <script>
            "use strict";

            /** Handler when the DOM is fully loaded. */
            let callback_<?php esc_attr_e( $this->get_id() ); ?> = function() {

                /** Set theme for coder widget. */
                function setTheme() {

                    /** Foreach Code Widget. */
                    let coderBoxes = document.querySelectorAll( '.mdp-coder-elementor-box' );

                    for ( let coderBox of coderBoxes ) {

                        let lightTheme = coderBox.dataset.theme;
                        let darkTheme = coderBox.dataset.darkTheme;

                        coderBox.className = '';
                        if ( window.matchMedia && window.matchMedia( '(prefers-color-scheme: dark)' ).matches ) {

                            coderBox.className = 'mdp-coder-elementor-box ' + darkTheme;

                        } else {

                            coderBox.className = 'mdp-coder-elementor-box ' + lightTheme;

                        }

                    }

                }
                setTheme();


                /** Watch for changes color-scheme. */
                window.matchMedia("(prefers-color-scheme: dark)").addListener( function() {
                    setTheme();
                } );

                <?php
                if ( Plugin::$instance->editor->is_edit_mode() || Plugin::$instance->preview->is_preview_mode() ) : ?>

                elementorFrontend.hooks.addAction( 'frontend/element_ready/mdp-coder-elementor.default', function () {

                    if ( typeof Prism !== 'undefined' ) {

                        Prism.plugins.autoloader.languages_path = '<?php esc_html_e( $lang_path ); ?>';
                        Prism.highlightAll();
                        Prism.fileHighlight();

                    }

                    setTheme();

                } );

                <?php else : ?>

                if ( typeof Prism !== 'undefined' ) {

                    Prism.plugins.autoloader.languages_path = '<?php esc_html_e( $lang_path ); ?>';
                    Prism.highlightAll();
                    Prism.fileHighlight();

                }

                <?php endif; ?>

            };

            if (
                document.readyState === "complete" ||
                ( document.readyState !== "loading" && !document.documentElement.doScroll )
            ) {
                callback_<?php esc_attr_e( $this->get_id() ); ?>();
            } else {
                document.addEventListener( "DOMContentLoaded", callback_<?php esc_attr_e( $this->get_id() ); ?> );
            }

        </script>
        <?php

    }

    /**
     * Render HTML widget output in the editor.
     *
     * Written as a Backbone JavaScript template and used to generate the live preview.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function deprecated_content_template() {
        ?>
        <!-- Start Coder for Elementor WordPress Plugin -->
        <div class="mdp-coder-elementor-box mdp-theme-<# print( settings.theme ); #>">
            <#
            if ( 'editor' === settings.source ) {

            #><pre class="language-<# print( settings.language ); #>"><code><#

                    /** Convert HTML to entities. */
                    let p = document.createElement( 'p' );
                    p.textContent = settings.code_editor;
                    let converted = p.innerHTML;
                    print( converted );

                    #></code></pre><#

            } else if ( 'url' === settings.source ) {

            if ( settings.code_url.trim().length < 3 ) {

            #><pre class="language-none">Enter a valid file link.</pre><#

            } else {

            #><pre class="language-<# print( settings.language ); #>" data-src="<# print( settings.code_url ); #>"></pre><#

            }

            }

            #>
        </div>
        <!-- End Coder for Elementor WordPress Plugin -->
        <?php
    }

    /**
     * Return language slug.
     *
     * @param string|array $language - Language to code highlight.
     *
     * @since  1.0.0
     * @access public
     * @return string
     **/
    private function fix_language( $language ) {

        /** Convert array to string. */
        if ( is_array( $language ) ) {
            $language = $language[0];
        }

        return $language;

    }

    /**
     * Return link for documentation
     * Used to add stuff after widget
     *
     * @access public
     *
     * @return string
     **/
    public function get_custom_help_url() {

        return 'https://docs.merkulov.design/tag/coder';

    }

}
